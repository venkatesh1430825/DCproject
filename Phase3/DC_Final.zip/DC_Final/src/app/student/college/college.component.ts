import { Component } from '@angular/core';
import { Router } from '@angular/router';


  
interface USERS {
    id: Number;
    name: String;
    username: String;
    email: String;
    link: String;
}

@Component({
  selector: 'app-College',
  templateUrl: './college.component.html',
  
  styleUrls: ['./college.component.css']
})



export class CollegeComponent {
  
    Users:any=[];

  constructor(private router: Router){

    this.Users=[{
        "id": "Wright State University",
        "name": "Computer Science",
        "username": "27000",
        "email": "Dayton,Ohio",
        "link":"https://engineering-computer-science.wright.edu/computer-science-and-engineering/master-of-science-in-computer-science",
        "link1": "https://www.wright.edu/",
        "link2": "https://www.wright.edu/admissions/international/graduate-tuition-and-fees",
    },
      {
        "id": "Ohio State University",
        "name": "Computer Science",
        "username": "32000",
        "email": "Columbus,Ohio",
        "link":"https://cse.osu.edu/",
        "link1": "https://www.osu.edu/",
        "link2": "https://registrar.osu.edu/FeeTables/MainFeeTables.asp",
      },
      {
        "id": "George Mason",
        "name": "Data Science",
        "username": "38000",
        "email": "Vrigina",
        "link":"https://catalog.gmu.edu/colleges-schools/engineering/data-analytics-engineering-ms/"
      },
      {
        "id": "University of South Florida",
        "name": "Data Science",
        "username": "31000",
        "email": "Jacksonville",
        "link":"https://www.usf.edu/arts-sciences/departments/information/research/data-analytics.aspx"
      }
      
    ]
   
}

gotoprofilepage(){
 
    this.router.navigate(['www.google.com']);
}
}