import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-Student',
  templateUrl: './Student.component.html',
 
})


export class StudentComponent  {
    constructor(private router: Router) { }

    

    login(){
        this.router.navigate(['dashboard']);
    }

    moveToRegister(){
      this.router.navigate(['college']);
    }
}