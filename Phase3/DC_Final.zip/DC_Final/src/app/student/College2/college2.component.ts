import { Component } from '@angular/core';
import { Router } from '@angular/router';


  
interface USERS {
    id: Number;
    name: String;
    username: String;
    email: String;
    link: String;
}

@Component({
  selector: 'app-College2',
  templateUrl: './College2.component.html',
  
  styleUrls: ['./College2.component.css']
})



export class College2Component {
  
    Users:any=[];

  constructor(private router: Router){

    this.Users=[{
        "id": "University of Iowa",
        "name": "Computer Science",
        "username": "20000",
        "email": "Iowa",
        "link":"https://cs.uiowa.edu/"
      },
      {
        "id": "University of Maryland",
        "name": "Data Science and Analytics",
        "username": "45000",
        "email": "College Park, Maryland",
        "link":"https://gradschool.umd.edu/computermathematicalnatural-sciences/mpda"
      },
      {
        "id": "Florida Institute of Technology",
        "name": "Computer Engineering",
        "username": "25000",
        "email": "Melbourne,Florida",
        "link":"https://www.fit.edu/engineering-and-science/academics-and-learning/computer-engineering-and-sciences/"
      },
      {
        "id": "Penn State University",
        "name": "Data Science",
        "username": "34000",
        "email": "University Park, Pennsylvania",
        "link":"https://datasciences.psu.edu/"
      }
      
    ]
   
}

gotoprofilepage(){
 
    this.router.navigate(['www.google.com']);
}
}