import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-Studentjob',
  templateUrl: './Studentjob.component.html',
  styleUrls: ['./Studentjob.component.css']
})


export class StudentjobComponent  {


    

}