import { Component } from '@angular/core';
import { Router } from '@angular/router';


  
interface USERS {
    id: Number;
    name: String;
    username: String;
    email: String;
    link: String;
}

@Component({
  selector: 'app-College1',
  templateUrl: './College1.component.html',
  
  styleUrls: ['./College1.component.css']
})



export class College1Component {
  
    Users:any=[];

  constructor(private router: Router){

    this.Users=[{
        "id": "Suny Buffalo",
        "name": "Data Science",
        "username": "29000",
        "email": "Buffalo,New York",
        "link":"http://www.buffalo.edu/academics/degree_programs.host.html/content/authoritative/grad/programs/engineering-science-data-science-ms.detail.html"
      },
      {
        "id": "University of North Texas",
        "name": "Computer Science",
        "username": "22000",
        "email": "Denton,Texas",
        "link":"https://computerscience.engineering.unt.edu/"
      },
      {
        "id": "University of Illinois at Chicago",
        "name": "Business Analytics",
        "username": "48000",
        "email": "Chicago,Illinois",
        "link":"https://business.uic.edu/graduate-programs/graduate-degrees/master-science-business-analytics/"
      },
      {
        "id": "University of Michigan",
        "name": "Computer Science",
        "username": "35000",
        "email": "Ann Arbor,Michigan",
        "link":"https://cse.engin.umich.edu/"
      }
      
    ]
   
}

gotoprofilepage(){
 
    this.router.navigate(['www.google.com']);
}
}