import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-CollegeDetails',
  templateUrl: './CollegeDetails.component.html',
 
})


export class CollegeDetailsComponent  {
    
    Users:any=[];
        constructor(private router: Router){
      
          this.Users=[{
              "id": "Wright State University",
              "name": "Computer Science",
              "username": "27000",
              "email": "Dayton,Ohio",
              "Link":"https://engineering-computer-science.wright.edu/computer-science-and-engineering/master-of-science-in-computer-science"
            },
            {
              "id": "Ohio State University",
              "name": "Computer Science",
              "username": "32000",
              "email": "Columbus,Ohio",
              "Link":"https://www.facebook.com/"
            },
            {
              "id": "George Mason",
              "name": "Data Science",
              "username": "38000",
              "email": "Vrigina",
              "Link":"https://www.facebook.com/"
            },
            {
              "id": "South Florida",
              "name": "Data Science",
              "username": "31000",
              "email": "Jacksonville",
              "Link":"https://www.facebook.com/"
            }
            
          ]
        
    }

    

    
}