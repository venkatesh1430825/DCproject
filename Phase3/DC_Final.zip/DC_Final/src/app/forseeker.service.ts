import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment } from '../environments/environment';

const PRIVATE='https://naukaries.herokuapp.com/private/';
const PUBLIC='https://naukaries.herokuapp.com/public/';

@Injectable({
  providedIn: 'root'
})

export class ForseekerService {

  jobs:any=[];

  appliedjobs:any=[];

  


  
  constructor(private httpCli:HttpClient) { 
    this.jobs=this.jobs=[
     {
        "companyName": "IBM",
      "jobDetails": {
      "jobRole":"Software Developer",
      "expRequired":"3",
      "jobType":"Full Time",
      "skills":"Java"
      
    }
  }
  
  /*
      {
        "companyName": "IBM",
      "jobDetails": {
      "jobRole":"Salesforce Developer",
      "expRequired":"1-5",
      "jobType":"Permanent",
      "skills":"Angular"
      
    }
  },
    {
       "companyName": "TCS",
      "jobDetails": {
      "jobRole":"Software Engineer",
      "expRequired":"2-5",
      "jobType":"Contract",
      "skills":"Java"
    }
    
    },
    {
      "companyName": "ServiceNow",
     "jobDetails": {
     "jobRole":"Data Engineer",
     "expRequired":"Fresher",
     "jobType":"Fulltime",
     "skills":"Tableau, Power BI, ETL, AWS"
   }
  },
  {
    "companyName": "Google",
   "jobDetails": {
   "jobRole":"Test Lead",
   "expRequired":"10-12",
   "jobType":"Permanent",
   "skills":"Automation, Agile methodology"
 }
}
*/
  ]
  }
  
  login(body:any){
    return this.httpCli.post(`${PUBLIC}employee/login`,body
    ,{
      observe:'body',
      withCredentials:true,
      headers:new HttpHeaders().append('Content-Type','application/json')
    }
    );
  }
  employee_register(body:any){
    return this.httpCli.post(`${PUBLIC}addemployee`,body,
    {
      observe:'body',
      headers:new HttpHeaders().append('Content-Type','application/json')
    }
    );
  }

  



  getjobs()
  {
   /* const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json, text/plain, *',
         'Content-Type':'application/json',
        'Authorization': 'Bearer '+this.gettoken()
      })
    };
    console.log(httpOptions);
  return this.httpCli.get(`${PRIVATE}employees/getjobs/${this.getpayload().id}`,httpOptions);

  */

  return this.jobs;
  }
  searchbycompany(companyname)
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json, text/plain, */*',
         'Content-Type':'application/json',
        'Authorization': 'Bearer '+this.gettoken()
      })
    };
    return this.httpCli.get(`${PRIVATE}employees/companyname/${companyname}`,httpOptions);
  }
  searchbyrole(jobrole:any)
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json, text/plain, */*',
         'Content-Type':'application/json',
        'Authorization': 'Bearer '+this.gettoken()
      })
    };
    return this.httpCli.get(`${PRIVATE}employees/jobrole/${jobrole}`,httpOptions);
  }
  searchlatestjobs()
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json, text/plain, */*',
         'Content-Type':'application/json',
        'Authorization': 'Bearer '+this.gettoken()
      })
    };
    return this.httpCli.get(`${PRIVATE}employees/latest`,httpOptions);
  }
   applyjob(jobit:any)
  {
    /*
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization': 'Bearer'+' '+this.gettoken()
      })
    };
    let job_id:any=jobs.jobDetails._id;
    let emp_id:any=this.getpayload().id;
    
    return this.httpCli.get(`${PRIVATE}employees/apply/${emp_id}/${job_id}`,httpOptions);
*/


this.appliedjobs=this.appliedjobs=[
  
 {
    "companyName": "IBM",
  "jobDetails": {
  "jobRole":"Software Developer",
  "expRequired":"3",
  "jobType":"Full Time",
  "skills":"Java"
  
}
},
  
 
]


 //this.appliedjobs= jobit;
 //console.log(this.appliedjobs);
 return this.appliedjobs;
 
}
  getappliedjobs()
  {
    
    this.appliedjobs=this.appliedjobs=[
      
       {
    "companyName": "IBM",
  "jobDetails": {
  "jobRole":"Software Developer",
  "expRequired":"3",
  "jobType":"Full Time",
  "skills":"Java",
  "status":"Applied"
}

},
    
    
    ]

    
    
     //this.appliedjobs= jobit;
     //console.log(this.appliedjobs);
     return this.appliedjobs;
  }
  uploadprofilepic(fd:any)
  {
    return this.httpCli.post(`${PRIVATE}employee/uploadpicture/${this.getpayload().id}`,fd);
   
  }
gettoken()
{
  return localStorage.getItem('token');
}
getpayload()
{
  let token=this.gettoken();
  return JSON.parse(window.atob(token.split('.')[1])); 
}
Empupdateprofile(body:any)
{
  return this.httpCli.put(`${PRIVATE}employees/editprofile`,body,
  {
    
      observe:'body',
      headers:new HttpHeaders().append('Content-Type','application/json')
    
  });
}
getprofile()
{
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':'application/json',
      'Authorization': `Bearer${this.gettoken()}`
    })
  };
  return this.httpCli.get(`${PRIVATE}employees/profile/${this.getpayload().id}`,httpOptions);
}
logout()
{
  localStorage.removeItem('token');
  localStorage.removeItem('currentemployee');
  localStorage.removeItem('currentemployeeid')
}
}
