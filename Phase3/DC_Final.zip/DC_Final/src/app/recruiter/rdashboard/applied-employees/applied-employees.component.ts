import { Component, OnInit } from '@angular/core';
import{Router,ActivatedRoute,ParamMap} from '@angular/router';
import{ForrecruiterService} from '../../../forrecruiter.service';

interface Seekers {
  name: String;
  experience: String;
  role: String;
  technology: String;
  request: String;
  reject: String;
  }

@Component({
  selector: 'app-applied-employees',
  templateUrl: './applied-employees.component.html',
  styleUrls: ['./applied-employees.component.css']
})
//export class AppliedEmployeesComponent implements OnInit {
  export class AppliedEmployeesComponent{
  Seekers:any=[]

  //headers=['SeekerName','SeekerMail','SeekerMobile','SeekerLoc','Interests','AppliedFor',''];

  headers=['Name', 'Experience', 'Role', 'Technology', 'Approve/Reject'];
  seekersInfo:any=[];
  seekerinterest:any;
  notapplied:any;
  errormsg:any;
  //constructor(private router:Router,private activeroute:ActivatedRoute,private recservice:ForrecruiterService) { }

  constructor(private router: Router){

    this.Seekers=[
      {
        "name": "Venkatesh",
        "experience": "2.8",
        "role": "Software Engineer",
        "technology": "JAVA",
        "request": "Request Background Check",
        "reject": "Reject"
      },
    ]
    /*  {
        "name": "Virat",
        "experience": "3",
        "role": "Software Architect",
        "technology": "Python",
        "request": "Request Background Check",
        "reject": "Reject"
      },
      {
        "name": "Rohit",
        "experience": "5",
        "role": "Software Architect II",
        "technology": "JAVA Full Stack",
        "request": "Request Background Check",
        "reject": "Reject"
      },
      {
        "name": "Dhoni",
        "experience": "10",
        "role": "Business Head",
        "technology": "JAVA, Python Full stack",
        "request": "Request Background Check",
        "reject": "Reject"
      },
    
*/
    
  /*ngOnInit() {
  //  setTimeout(()=>{
  //   this.getSeekers();
  //  },5000);
   this.getSeekers();
  }*/


/*getSeekers()
{
  this.recservice.getseekers().subscribe(
    (response:any)=>{
      if(response.status && response.status===1)
      {
        this.seekersInfo=response.employeearray;
       // this.seekerinterest=response.employeearray.details.interests;
        console.log(this.seekersInfo);
      }
      else{
        this.notapplied=response.message;
        console.log(this.notapplied);
      }

    },(error:any)=>{
      this.errormsg="Internal Server Error/Server Issues";
    }
  )
}*/
/*call_for_interview(info){
  window.alert("Yor selected");
}
reject(info){
  window.alert("your rejected");
}*/
}
}
