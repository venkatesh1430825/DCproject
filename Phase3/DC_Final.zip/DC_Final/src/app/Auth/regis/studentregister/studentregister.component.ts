import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {FormBuilder,FormControl,FormGroup,Validators} from '@angular/forms';
import { ForstudentService } from '../../../student.service';
@Component({
  selector: 'app-studentregister',
  templateUrl: './studentregister.component.html',
  styleUrls: ['./studentregister.component.css']
})
export class StudentregisterComponent implements OnInit {

    constructor(private router:Router,private fb:FormBuilder,private seekerservice:ForstudentService) { }
    studentRegisterForm:FormGroup;
    registrationsuccess:any;
    regisfail:any;
    regisserver:any;
    ngOnInit() {
      this.studentRegisterForm=this.fb.group({
        username: ['',Validators.required],
        password: ['',Validators.compose([Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"),Validators.minLength(8)])],
        mail:['',Validators.compose([Validators.required,Validators.email])],
        gender: ['',Validators.required],
        mobile: ['',Validators.required],
        hometown: [''],
        interests: [''],
        experience: [''],
        maritalStatus: ['',Validators.required],
        nationality: [''],
        languages: [''],
        currentLocation: [''],
        lastjobexp: ['',Validators.required],
        lastjobDesig: ['',Validators.required],
        department: [''],
        reasonsforleaving: ['']
        });
    }
    registerstudent()
    {
      //console.log(this.EmpRegisterForm.value);
      this.seekerservice.student_register(JSON.stringify(this.studentRegisterForm.value)).subscribe(
        (response:any)=>{
          if(response.status===1){
            this.registrationsuccess='Congratulations your now a job seeker';
            this.studentRegisterForm.reset();
              setTimeout(() => {
                this.router.navigate(['/login/emp_login']);
              }, 3000);
          }else{
            this.regisfail='You are already a job seeker';
            console.log(this.regisfail);
          }
        },
        (error)=>{
            this.regisserver='Internal server error'; 
        }
  
      );
    }
  
  }
  