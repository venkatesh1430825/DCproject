import { Component, OnInit } from '@angular/core';
import{ForseekerService} from '../../../forseeker.service';
@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {


jobs:any=[];
applieddummyjobs:any=[];
waitforjobs:any;
appliedmessage:any;
alreadyapplied:any;
errormessage:any;
totaljobs:any;
headers=['Company Name','Job Role','Skills','Job Type','Experience',''];
  constructor(private seekerservice:ForseekerService) { }
  ngOnInit() {
  this.getjobs();
  }

  getjobs()
  {
    
    this.jobs=  this.seekerservice.getjobs();
     

    

  }
  apply(jobapply:any)
  {
    
   

    //this.alreadyapplied= this.seekerservice.getappliedjobs();
   //console.log(this.alreadyapplied);
   
 

  }
}
